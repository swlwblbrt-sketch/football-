# Football Predictions

Готовый простой сайт футбольных прогнозов для загрузки в GitHub и публикации через Render.

Главный файл сайта: `index.html`
